package com.example.test4

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

@Composable
fun Icecream(navController : NavController){
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFFFDAB9))
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ){
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFFAEC6CF))
        ){
            Image(
                painter = painterResource(id = R.drawable.s1 ),
                contentDescription = null
            )
            Text(text = "The Endless Coconut Summer Surprise!")
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFFAEC6CF))
        ){
            Image(
                painter = painterResource(id = R.drawable.s2 ),
                contentDescription = null
            )
            Text(text = "The Striped Pinkitist")
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFFAEC6CF))
        ){
            Image(
                painter = painterResource(id = R.drawable.s3 ),
                contentDescription = "null"
            )
            Text(text = "Tinted Lemon and Raspberries Meringue")
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFFAEC6CF))
        ){
            Image(
                painter = painterResource(id = R.drawable.s4),
                contentDescription = "hi1"
            )
            Text(text = "Berry Bert's Chocolate Treasure")
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFFAEC6CF))
        ){
            Image(
                painter = painterResource(id = R.drawable.s5 ),
                contentDescription = "hi"
            )
            Text(text = "Caramellia, Butterscotchitie and Vanill")
        }
    }
}