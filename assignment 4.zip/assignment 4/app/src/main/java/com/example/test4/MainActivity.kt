package com.example.test4

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.navigation.NavHost
import com.example.test4.ui.theme.Test4Theme
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.rememberNavController
import androidx.navigation.compose.composable

@Composable
fun MyApp(){
    val navController = rememberNavController()
    NavHost(
        navController = navController,
        startDestination = "Login1"
    ){
        composable("Login1"){ Login11(navController) }
        composable("Restuarant"){ Restaurant(navController) }
        composable("Food"){Food(navController)}
        composable("Donut"){ Donut(navController)}
        composable("Icecream"){Icecream(navController)}
    }
}

fun Restuarant() {
    TODO("Not yet Implemented")
}
fun Food() {
    TODO("Not yet Implemented")
}
fun Icecream() {
    TODO("Not yet Implemented")
}
fun Donut() {
    TODO("Not yet Implemented")
}
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent{
            MyApp()
        }
    }

}
@Preview
@Composable
fun MyAppPreview() {

}
@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    MyAppPreview()
}
/**
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Test4Theme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    Greeting("Android")
                }
            }
        }
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "Hello $name!",
        modifier = modifier
    )
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    Test4Theme {
        Greeting("Android")
    }
}
        **/